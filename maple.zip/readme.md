去EasyX官网下载最新图形库依赖包安装（官网有教程）

确保装好了gcc环境

直接编译运行first.cpp即可

仅供娱乐

by caoxuhua.cn

