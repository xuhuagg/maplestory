void ShowUnderBar()
{
	int level;
	putimage(688,514,&itemTable);
	putimage(ubar.barX,ubar.barY,&ubar.barPic);
	level = man.level;
/*	if(level < 10){
		putimage(ubar.levelX,ubar.levelY,&ubar.level[level]);
	}
	else{
		putimage(ubar.levelX,ubar.levelY,&ubar.level[level/10]);
		putimage(ubar.levelX + ubar.levelWidth,ubar.levelY,&ubar.level[level%10]);
	}*/
	outtextxy(ubar.levelX,ubar.levelY,"1");
}

void SelectColumn(MOUSEMSG m)
{
	if(m.x >= ubar.proX && m.x < ubar.packX && m.y >= 565 && m.y < 600){
		putimage(ubar.proX,ubar.proY,&ubar.table[1],NOTSRCERASE);
		putimage(ubar.proX,ubar.proY,&ubar.table[0],SRCINVERT);
//		mciSendString("play Tab from 0", NULL, 0, NULL);
	}
	if(m.x >= ubar.packX && m.x < ubar.skiX && m.y >= 565 && m.y < 600){
		putimage(ubar.packX,ubar.packY,&ubar.table[1],NOTSRCERASE);
		putimage(ubar.packX,ubar.packY,&ubar.table[0],SRCINVERT);
//		mciSendString("play Tab from 0", NULL, 0, NULL);
	}
	if(m.x >= ubar.skiX && m.x < 800 && m.y >= 565 && m.y < 600){
		putimage(ubar.skiX,ubar.skiY,&ubar.table[1],NOTSRCERASE);
		putimage(ubar.skiX,ubar.skiY,&ubar.table[0],SRCINVERT);
//		mciSendString("play Tab from 0", NULL, 0, NULL);
	}
}

void ShowDamagePic(int damage,int i,int tag)
{
	int gNum,sNum,bNum,qNum;			//个十百千
	gNum = damage%10;
	sNum = (damage%100-gNum)/10;
	qNum = damage/1000;
	bNum = (damage-qNum*1000)/100;
	
	if(tag == FlowerMushroom)
	{
		if(gNum > 0 && sNum == 0 && bNum == 0 && qNum == 0){
			putimage(flowerMushroom[i].x + x +10,flowerMushroom[i].y - 40,&damegePic[1][gNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +10,flowerMushroom[i].y - 40,&damegePic[0][gNum],SRCINVERT);
		}
		if(gNum > 0 && sNum > 0 && bNum == 0 && qNum == 0){
			putimage(flowerMushroom[i].x + x,flowerMushroom[i].y - 40,&damegePic[1][sNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x,flowerMushroom[i].y - 40,&damegePic[0][sNum],SRCINVERT);
			putimage(flowerMushroom[i].x + x +20,flowerMushroom[i].y - 40,&damegePic[1][gNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +20,flowerMushroom[i].y - 40,&damegePic[0][gNum],SRCINVERT);
		}
		if(gNum > 0 && sNum > 0 && bNum > 0 && qNum == 0){
			putimage(flowerMushroom[i].x + x -10,flowerMushroom[i].y - 40,&damegePic[1][bNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x -10,flowerMushroom[i].y - 40,&damegePic[0][bNum],SRCINVERT);
			putimage(flowerMushroom[i].x + x +10,flowerMushroom[i].y - 40,&damegePic[1][sNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +10,flowerMushroom[i].y - 40,&damegePic[0][sNum],SRCINVERT);
			putimage(flowerMushroom[i].x + x +30,flowerMushroom[i].y - 40,&damegePic[1][gNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +30,flowerMushroom[i].y - 40,&damegePic[0][gNum],SRCINVERT);
		}
		if(gNum > 0 && sNum > 0 && bNum > 0 && qNum > 0){
			putimage(flowerMushroom[i].x + x -10,flowerMushroom[i].y - 40,&damegePic[0][qNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x -10,flowerMushroom[i].y - 40,&damegePic[0][qNum],SRCINVERT);
			putimage(flowerMushroom[i].x + x +10,flowerMushroom[i].y - 40,&damegePic[0][bNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +10,flowerMushroom[i].y - 40,&damegePic[0][bNum],SRCINVERT);
			putimage(flowerMushroom[i].x + x +30,flowerMushroom[i].y - 40,&damegePic[0][sNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +30,flowerMushroom[i].y - 40,&damegePic[0][sNum],SRCINVERT);
			putimage(flowerMushroom[i].x + x +50,flowerMushroom[i].y - 40,&damegePic[0][gNum],NOTSRCERASE);
			putimage(flowerMushroom[i].x + x +50,flowerMushroom[i].y - 40,&damegePic[0][gNum],SRCINVERT);
		}
		Sleep(5);
	}
}

void ShowBus()
{
	int term = (bus.index++)%30/5;

	putimage(bus.x+x,bus.y,&bus.busPic[1],NOTSRCERASE);
	putimage(bus.x+x,bus.y,&bus.busPic[0],SRCINVERT);
	if(bus.quanTag == YES)
	{
		putimage(bus.quanX+x,bus.quanY-term,&bus.quan[1][4],NOTSRCERASE);
		putimage(bus.quanX+x,bus.quanY-term,&bus.quan[0][4],SRCINVERT);
	}
	if(bus.selectTag == YES)
	{
		putimage(bus.pX+x,bus.pY,&bus.pagePic[1],NOTSRCERASE);
		putimage(bus.pX+x,bus.pY,&bus.pagePic[0],SRCINVERT);	
	}
}


void ShowOperationTool()
{
	putimage(operationTool.mx,operationTool.my,&operationTool.mark);
	if(operationTool.flag == YES)
	{
		putimage(operationTool.x,operationTool.y,&operationTool.toolPic[1],NOTSRCERASE);
		putimage(operationTool.x,operationTool.y,&operationTool.toolPic[0],SRCINVERT);
	}
}


void ShowPacket()
{
	char s[10];
	if(packet.flag == YES)
	{
		putimage(packet.x+x,packet.y,&packet.backPic);
		sprintf(s,"%d",packet.num[0]);
		outtextxy(514+x,115,s);
		sprintf(s,"%d",packet.num[1]);
		outtextxy(514+x,173,s);
	}
}

void ShowSkillTable()
{
	char s[10];
	if(skillTable.flag ==YES)
	{
		putimage(skillTable.x+x,skillTable.y,&skillTable.backPic);
		sprintf(s,"%d",skillTable.num[0]);
		outtextxy(445+x,137,s);
		sprintf(s,"%d",skillTable.num[1]);
		outtextxy(445+x,197,s);
		sprintf(s,"%d",skillTable.totalPoint);
		outtextxy(517+x,312,s);
	}
}

void ShowTransPoint()
{
	if(showFirstMap == YES)
	{
		int width = 0;
		width = man.x - x+man.width;

		if(man.y == 432 &&(width >= 340 && width <= 435))
		{
			putimage(firstPoint[0].pX+x,firstPoint[0].pY,&pointIco[0],NOTSRCERASE);
			putimage(firstPoint[0].pX+x,firstPoint[0].pY,&pointIco[1],SRCINVERT);
		}
		if((man.y == 258) && (width >= 590 && width <=655))
		{
			putimage(firstPoint[1].pX+x,firstPoint[1].pY,&pointIco[0],NOTSRCERASE);
			putimage(firstPoint[1].pX+x,firstPoint[1].pY,&pointIco[1],SRCINVERT);
		}
		if((man.y == 80) && (width >= 570 && width <=655))
		{
			putimage(firstPoint[2].pX+x,firstPoint[2].pY,&pointIco[0],NOTSRCERASE);
			putimage(firstPoint[2].pX+x,firstPoint[2].pY,&pointIco[1],SRCINVERT);
		}
	}
	
	if(showSecondMap == YES)
	{
		int width = 0;
		width = man.x-x + man.width;
		if(man.y == 520 - man.high && width >= 470 && width <= 530)
		{
			putimage(secondPoint[0].pX+x,secondPoint[0].pY,&pointIco[0],NOTSRCERASE);
			putimage(secondPoint[0].pX+x,secondPoint[0].pY,&pointIco[1],SRCINVERT);
		}
		
		if(man.y == 392 - man.high && width >= 610 && width <= 700)
		{
			putimage(secondPoint[1].pX+x,secondPoint[1].pY,&pointIco[0],NOTSRCERASE);
			putimage(secondPoint[1].pX+x,secondPoint[1].pY,&pointIco[1],SRCINVERT);
		}
	}
}

void MapEdgeJudge()
{
	if(showFirstMap == YES)
	{
		if((man.x-x+man.width/2 <= 305|| man.x-x >= 805) && man.y == 80)
		{
			maple[1].t[0][0] = YES;
		}
			
		if(maple[1].t[0][0] == NO && (man.x-x+man.width/2 <= 235|| man.x-x >= 945) && (man.y==258))
		{
			maple[1].t[1][0] = YES;
		}
		
		DecriHight(0);
		DecriHight(1);
	}
	
	if(showSecondMap == YES)
	{
/*		if(man.x-x >= 506 && man.y == 105)
		{
			maple[2].t[0][0] = YES;
		}
		if(man.x-x < 500 && man.y >105 && man.y <= 168 )
		{
			man.x = 500 + x;
			if((GetAsyncKeyState(VK_LEFT) & 0x8000) && jumpTag)
				maple[2].t[1][0] = YES;
		}

		DecriHight(0);
		DecriHight(1);*/
	}

	//跳到另一个不等高物体上
	
}

void DecriHight(int term)
{
	if(showFirstMap == YES)
	{
		if(term == 0 && maple[1].t[0][0] == YES)				//第一层，达到下落条件
		{
			jumpTag = NO;										//在空中不能跳跃
			
			man.y += maple[1].t[0][maple[1].index%10];
			maple[1].index++;
			if(maple[1].index == 10)								//到达第二层，置标识为0
			{
				maple[1].t[0][0] = NO;
				maple[1].index = 1;
			}
		}
		if(term == 1 && maple[1].t[1][0] == YES)				//第二层，达到下落条件
		{
			jumpTag = NO;										//在空中不能跳跃
			
			man.y += maple[1].t[1][maple[1].index%10];			//改了
			maple[1].index++;
			if(maple[1].index == 10)
			{
				maple[1].t[1][0] = NO;							//到达第三层，置标识为0
				maple[1].index = 1;
			}			
		}
	}
	
	if(showSecondMap == YES)
	{
	/*	if(term == 0 && maple[2].t[0][0] == YES)
		{
			jumpTag = NO;
			man.y += maple[2].t[0][maple[2].index%5];
			maple[2].index++;
			if(maple[2].index == 5)
			{
				maple[2].t[0][0] = NO;
				maple[2].index = 1;
			}
		}
		if(term == 1 && maple[2].t[1][0] == YES)
		{
			jumpTag = NO;
			jump = 0;
			man.y = 105;
			maple[2].t[1][0] = NO;
		}*/
	}
}	

void ShowExpColumn()
{
	setfillcolor(WHITE);
	solidrectangle(man.hpX,580,man.hpEX,596);
	
//	setfillcolor(WHITE);
	solidrectangle(man.mpX,580,man.mpEX,596);
	
//	setfillcolor(WHITE);
	solidrectangle(man.expX,582,man.expEX,596);
	
}












