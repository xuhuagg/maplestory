void FirstMap()
{
	InitFirstMap();
	mciSendString("play MapFirst from 0", NULL, 0, NULL);
	BeginBatchDraw();
	do
	{
		putimage(x,0,&maple[1].background);
		ShowUnderBar();
		ShowExpColumn();
		ShowTransPoint();
		MonsterMove();
		GetCmd(maple[1]);
		ShowPacket();
		ShowSkillTable();
		ShowOperationTool();
		while(MouseHit())
		{
			MS = GetMouseMsg();
			Mouse(MS);
			SelectColumn(MS);
		}
		putimage(MS.x,MS.y,&mouse[1],NOTSRCERASE);
		putimage(MS.x,MS.y,&mouse[0],SRCINVERT);
		FlushBatchDraw();
		Sleep(20);		
		
	}while(showFirstMap != NO);	
	EndBatchDraw();
}