#include<graphics.h> 
#include<easyx.h>       
#include<stdio.h> 
#include<conio.h> 
#include<winsock2.h>
#include<stdlib.h> 
#include<String.h> 
#include <time.h>
#include<windows.h>
#include <mmsystem.h>
#include <math.h>
// ���ؿ⺯��
#pragma comment( lib, "msimg32.lib")
#pragma comment( lib, "winmm.lib")

// ���峣��
#define SCREENWIDTH		800	
#define SCREENHEIGHT	600
#define YES 1
#define NO 0
enum {FlowerMushroom};
enum {right, left, up, down};		//4������
enum {First,Second,Third,Fourth};	//�ĸ���ͼ���
int mapTag;							//bus��ͼѡ���ǩ
int showTip;
int showReadyMap;
int showFirstMap;		//��ͼ���ɱ��
int showSecondMap;
int showThirdMap;
int showFourthMap;
//  ����ṹ��

typedef struct skill
{
	int x;
	int y;
	int width;
	int high;
	int arrow;
	int delX;							//��δ�����߽磬����������룬����ʧЧ
	int attackPower;
	int speed;
	int img_index;
	int img_num;
	int alive;
	int originX;							//
	IMAGE attackPic[2][10];
}Skill;

typedef struct BODY{				//����ṹ��
	int x;
	int y;
	int width;						//ͼ����͸�
	int high;
	int arrow;						//��ǰ�ķ���
	int expX;      					//������
	int expEX;
	int hpX;						//Ѫ��
	int hpEX;
	int mpX;
	int mpEX;
	int pLength;					//����������
	Skill basicAttack[3];				//��������
	Skill skillAttack[2];			//���ܹ���	
	IMAGE attackpic[2][10];
	IMAGE movepic[2][8];
	IMAGE standpic[2][2];
	IMAGE jumppic[2][2];
	IMAGE skillpic[4][20];	
	int basicAttackPower;			//��������
	int skillAttackPower[2];			//���ܹ���
	int img_index;
	int img_num;
	int speed;						//�ٶ�
	IMAGE head;						//ͷ��
	IMAGE boss_pic[40];
	int alive;
	int blood;
	int level;						//����
}BodyInfo;

typedef struct game_{		//��Ʒ�������ù�����Ʒ������ټ�
	int x;
	int y;
	IMAGE img[2][1];
	int index;
	int flag;       //��ӡ��־
}ITEM;


typedef struct Monster
{
	int x;
	int y;
	int width;
	int high;
	int arrow;
	int rightEdge;
	int leftEdge;
	IMAGE movepic[2][20];
	IMAGE attackpic[2][30];
	IMAGE Skillpic[2][20];
	ITEM item[3];
	int basicAttackPower;				//��������
	int skillAttackPower[2];			//���ܹ���
	int speed;
	int img_index;
	int img_num;
	int alive;
	int blood;
	int judgeTerm;						//����λ����Ҫ
	int directNum;						//ָʾ����λ��
	int flag;    						//�ж��Ƿ��Ѿ�����ƶ�״̬
	int tag;							//�ֱ�����һ������
}Monster;


typedef struct maple_info{
	IMAGE background;
	int index;
	int t[4][10];
	int width;
	int hight;
	int sub_length;					//��ͼ����ʾ���ڵĲ�ֵ��ȫ��x��ȡֵ��Χ
									//Ϊ[0��sub_length],x����putimage(-sub_length,0);
}MapleInfo;

typedef struct TransPoint{
	int flag;
	int nextPoint[2][2];
	int pY;
	int pX;
}TransPoint;

typedef struct Under
{
	int barX,barY;
	int proFlag,packFlag,skiFlag;
	int proX,proY,packX,packY,skiX,skiY;
	int hpX,hpY,mpX,xpY,levelX,levelY;
	int levelWidth;
	IMAGE barPic;
	IMAGE level[10];
	IMAGE table[2];
}UnderBar;

typedef struct Bus
{
	IMAGE busPic[2];
	IMAGE pagePic[2];
	IMAGE selectPic[2];
	IMAGE quan[5][2];
	int selectPoint[4][2];
	int x;
	int y;
	int pX;
	int pY;
	int quanX;
	int quanY;
	int firstStartX;
	int firstEndX;
	int firstStartY;
	int firstEndY;
	int secondStartX;
	int secondEndX;
	int secondStartY;
	int secondEndY;
	int thirdStartX;
	int thirdEndX;
	int thirdStartY;
	int thirdEndY;
	int fourthStartX;
	int fourthEndX;
	int fourthStartY;
	int fourthEndY;
	int quanTag;
	int chancelTag;
	int goMapTag;
	int selectTag;
	int index;
}Bus;

typedef struct Operation
{
	IMAGE toolPic[2];
	IMAGE selectPic[2];
	IMAGE mark;
	int selectPoint[4][2];
	int x;
	int y;
	int mx;
	int my;
	int firstStartX;
	int firstEndX;
	int firstStartY;
	int firstEndY;
	int secondStartX;
	int secondEndX;
	int secondStartY;
	int secondEndY;
	int thirdStartX;
	int thirdEndX;
	int thirdStartY;
	int thirdEndY;
	int flag;
}Operation;


typedef struct ItemDetail
{
	IMAGE backPic;
	int x;
	int y;
	int totalPoint;
	int num[6];
	int position[6][2];
	int flag;
}ItemDetail;

//ȫ�ֱ���
IMAGE damegePic[2][10];
IMAGE mouse[2];
IMAGE pointIco[2];
IMAGE itemTable;
MapleInfo maple[5];	
TransPoint firstPoint[3];						//��ͼһͨ��
TransPoint secondPoint[4];						//��ͼ��ͨ��
UnderBar ubar;								//�½����
Bus bus;									//��ʼ������
ItemDetail packet;							//����
ItemDetail skillTable;						//���ܱ�
Operation operationTool;					//��������
int damegePicMove;							//�˺�ͼƬ����λ��
int PlayMusic;								// ��������
int x;										//�ƶ���ͼ
int y;
int delt_x;									//��¼x�ı仯��
int jump;
int jumpTag;									//��Խ��Ҫ
int attack;										//������Ҫ
int attackTag;
int moveTag;									//�ƶ�
BodyInfo man;									//����
Monster flowerMushroom[6],lvMushroom;				//����
int _jump[10] = {18,12,10,6,4,-4,-6,-10,-12,-18}; //��Ծλ��
int msMove[10];									//��������ƶ�
//����ģ��ѩ��Ч��
//���moveTagΪYES����ΪsnowAdd��1*SlideTag��SlideTagΪ1����-1����sonwAdd��DispatchMove�д���
//���moveTagΪNO����ΪsnowAdd��1���1���ȶ�snowAdd�����жϣ�ֱ����Ϊ0
int SlideTag;									//�󻬱��
int snowAdd;									//����λ�������±�

MOUSEMSG MS;


void GetCmd(MapleInfo maple);
void Mouse(MOUSEMSG MS);
void OnLeft(MapleInfo maple);
void OnRight(MapleInfo maple);
void OnJump();
void OnAttack();
void HandleX(int delt);
void PrintAttackGif();
void PrintJumpGif();
void PrintMoveGif();
void DispatchMove(MapleInfo maple);
void DispatchJump();
void DispatchAttack();
void InitFirstMap();
void FirstMap();
void MapTransJudge();
void ManCmdJudge(MapleInfo maple);
void DecriHight(int term);
void MapEdgeJudge();
void InitMonster();
void MonsterMove();
void GetMonsterDirection(int term);
void BowMove();
void BowRefresh();
void InitBusInfo();
void InitSkillInfo();
void MeetMonsterJudge(int tag,int term);
int MeetSkillJudge(Skill ,Monster);
void ShowUnderBar();
void SelectColumn(MOUSEMSG m);
void ShowDamagePic(int damage,int i,int tag);
void ShowBus();
void InitPacket();
void ShowPacket();
void ShowSkillTable();
void InitSkillTable();
void InitSecondMap();
void SecondMap();
void ShowTransPoint();
void MapEdgeJudge();
void DecriHight(int term);
void InitOperationTool();
void ShowOperationTool();
void ShowExpColumn();



void Mouse(MOUSEMSG m)
{
	int mx,my;
	mx = m.x;
	my = m.y;
	if(mx<0) mx=0;
	if(mx>800) mx=800;
	if(my<0) 	my=0;
	if(my>600) 	my=600;
	putimage(mx,my,&mouse[1],NOTSRCERASE);
	putimage(mx,my,&mouse[0],SRCINVERT);

	if(m.mkLButton)
		mciSendString("play Mousehit from 0", NULL, 0, NULL);
	
	if(showReadyMap == YES)
	{
		if(bus.quanTag == YES)
		{
			if(mx-x >= bus.quanX && mx-x <= bus.quanX + 46 && my >= bus.quanY && my <= bus.quanY + 36)
			{
				mciSendString("play Tab from 0", NULL, 0, NULL);
				if(m.mkLButton)
				{
					bus.quanTag=NO;
					bus.selectTag = YES;
					Sleep(10);
				}
			}
		}
		
		if(bus.selectTag == YES)
		{
			if(mx-x >= 350 && mx-x <= 375 && my >= bus.pY && my < bus.firstStartY)
			{
				if(m.mkLButton)
				{
					bus.selectTag = NO;
					bus.quanTag = YES;
					Sleep(10);
				}
			}
			
			if(mx-x >= bus.firstStartX && mx-x <= bus.firstEndX && my >= bus.firstStartY && my <= bus.fourthEndY)
			{
				if(my <= bus.firstEndY)
				{
				//	mciSendString("play Tab from 0", NULL, 0, NULL);
					putimage(bus.selectPoint[0][0]+x,bus.selectPoint[0][1],&bus.selectPic[1],NOTSRCERASE);
					putimage(bus.selectPoint[0][0]+x,bus.selectPoint[0][1],&bus.selectPic[0],SRCINVERT);
					if(m.mkLButton)
					{
						bus.quanTag = YES;
						bus.selectTag = NO;
						showReadyMap = NO;
						showFirstMap = YES;
						mapTag = First; 
					}
				}
				else if(m.y <= bus.secondEndY)
				{
				//	mciSendString("play Tab from 0", NULL, 0, NULL);
					putimage(bus.selectPoint[1][0]+x,bus.selectPoint[1][1],&bus.selectPic[1],NOTSRCERASE);
					putimage(bus.selectPoint[1][0]+x,bus.selectPoint[1][1],&bus.selectPic[0],SRCINVERT);
					if(m.mkLButton)
					{
						bus.quanTag = YES;
						bus.selectTag = NO;
						showReadyMap = NO;
						showSecondMap = YES;
						mapTag = Second; 
					}
				}
				else if(m.y <= bus.thirdEndY)
				{
				//	mciSendString("play Tab from 0", NULL, 0, NULL);
					putimage(bus.selectPoint[2][0]+x,bus.selectPoint[2][1],&bus.selectPic[1],NOTSRCERASE);
					putimage(bus.selectPoint[2][0]+x,bus.selectPoint[2][1],&bus.selectPic[0],SRCINVERT);
					if(m.mkLButton)
					{
						bus.quanTag = YES;
						bus.selectTag = NO;
						showReadyMap = NO;
						showFirstMap = YES;
						mapTag = First; 
					}
				}
				else
				{
				//	mciSendString("play Tab from 0", NULL, 0, NULL);
					putimage(bus.selectPoint[3][0]+x,bus.selectPoint[3][1],&bus.selectPic[1],NOTSRCERASE);
					putimage(bus.selectPoint[3][0]+x,bus.selectPoint[3][1],&bus.selectPic[0],SRCINVERT);
					if(m.mkLButton)
					{
						bus.quanTag = YES;
						bus.selectTag = NO;
						showReadyMap = NO;
						showFirstMap = YES;
						mapTag = First; 
					}
				}
				
			}
		}
	}
	
	if(mx >= 570 && mx <= 800 && my >= 565 && my <= 600)//����������
	{
		if(mx <= 647)
		{
			if(m.mkLButton)
			{
				//����������
			}
		}
		else if(mx <= 722)
		{
			if(m.mkLButton)
			{
				packet.flag = YES;
			}
		}
		else
		{
			if(m.mkLButton)
			{
				skillTable.flag = YES;
			}
		}
	}
	
	//���������
	if(mx >= 770 && mx <= 800 && my >= 0 && my<= 30 && operationTool.flag == NO)
	{
		mciSendString("play Tab from 0", NULL, 0, NULL);
		if(m.mkLButton)
		{
			operationTool.flag = YES;
		}
	}
	
	//ѡ�������Ŀ
	if(operationTool.flag == YES)
	{
		if(mx >= 522 && mx <= 555 && my >= 138 && my<= 165)		//�رղ�����
		{
			if(m.mkLButton)
			{
				operationTool.flag = NO;
			}
		}
		
		if(mx >= operationTool.firstStartX && mx <= operationTool.firstEndX && my >= operationTool.firstStartY && my <= operationTool.secondEndY)
		{
			if(my <= operationTool.firstEndY)
			{
				putimage(operationTool.selectPoint[0][0],operationTool.selectPoint[0][1],&operationTool.selectPic[1],NOTSRCERASE);
				putimage(operationTool.selectPoint[0][0],operationTool.selectPoint[0][1],&operationTool.selectPic[0],SRCINVERT);
				if(m.mkLButton)
				{
					showReadyMap = YES;
					showFirstMap = NO;
					showSecondMap = NO; 
					showThirdMap = NO;
					showFourthMap = NO;
					operationTool.flag = NO;
				}
			}
			else if(m.y <= operationTool.secondEndY)
			{
				putimage(operationTool.selectPoint[1][0],operationTool.selectPoint[1][1],&operationTool.selectPic[1],NOTSRCERASE);
				putimage(operationTool.selectPoint[1][0],operationTool.selectPoint[1][1],&operationTool.selectPic[0],SRCINVERT);
				if(m.mkLButton)
				{
					closegraph();
				}
			}
		}
	}
	
	if(packet.flag == YES)
	{
		if(mx-x >= 630 && mx-x <= 655 && my >= 66 && my <= 86)
		{
			if(m.mkLButton)
			{
				packet.flag = NO;
			}
		}
	}
	
	if(skillTable.flag ==YES)
	{
		if(mx-x >= 630 && mx-x <= 655 && my >= 66 && my <= 86)
		{
			if(m.mkLButton)
			{
				skillTable.flag = NO;
			}
		}
		if(mx-x >= 482 && mx-x <= 502 && my >= 135 && my <= 155)
		{
			if(m.mkLButton)
			{
				if(skillTable.totalPoint > 0)
				{
					skillTable.num[0]++;
					skillTable.totalPoint--;
				}
			}
		}
		if(mx-x >= 482 && mx-x <= 502 && my >= 194 && my <= 215)
		{
			if(m.mkLButton)
			{
				if(skillTable.totalPoint > 0)
				{
					skillTable.num[1]++;
					skillTable.totalPoint--;
				}
			}
		}
	}
	
}





