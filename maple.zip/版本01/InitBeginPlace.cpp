
void InitBeginPlace()
{
	int i,j,k;
	IMAGE manmove,manattack,manstand,manjump,FMushroom,bow,damage;
	// ��ʼ���������
	man.x = 400;
	man.y = 385;
	man.width = 60;
	man.high = 70;
	man.speed = 8;
	man.alive = 1;
	man.blood = 100;
	man.img_index = 0;
	man.arrow = left;
	//��̬����
	man.expX = 460;	//441
	man.expEX = 547;
	man.hpX = 325;
	man.hpEX = 325;
	man.mpX = 435;
	man.mpEX = 435;
	man.pLength = 106;
	//
	attackTag = NO;
	attack = 0;
	jumpTag = NO;
	jump = 0;
	moveTag = NO;
	mapTag = -1;
	// ��ʼ����ͼ����
	maple[0].width = 1021;
	maple[0].hight = 600;
	maple[0].sub_length = 221;
	maple[1].width = 1175;
	//��ͼ���ɱ��
	showTip = YES;
	showReadyMap = NO;
	showFirstMap = NO;
	showSecondMap = NO;
	showThirdMap = NO;
	showFourthMap = NO;
	//��ʼ������
	InitMonster();
	InitSkillInfo();
	// ����ͼƬ
	loadimage(&itemTable,"res\\system\\ItemColumn.jpg");
	loadimage(&mouse[0],"res\\system\\mouse.jpg");
	loadimage(&mouse[1],"res\\system\\ymouse.jpg");
	loadimage(&maple[0].background,"res\\map\\background.jpg");
	loadimage(&manmove,"res\\character\\move62.jpg");
	loadimage(&manattack,"res\\character\\attack66.jpg");
	loadimage(&manstand,"res\\character\\stand.jpg");
	loadimage(&manjump,"res\\character\\jump49.jpg");
	loadimage(&bow,"res\\skill\\bow80.jpg");	
	loadimage(&damage,"res\\system\\underbar\\damage.jpg");
	
	//�½����
	loadimage(&ubar.barPic,"res\\system\\underbar\\bar.jpg");
	loadimage(&ubar.table[0],"res\\system\\underbar\\select.jpg");
	loadimage(&ubar.table[1],"res\\system\\underbar\\yselect.jpg");
	loadimage(&ubar.level[0],"res\\system\\underbar\\LevelNo0.jpg");
	loadimage(&ubar.level[1],"res\\system\\underbar\\LevelNo1.jpg");
	loadimage(&ubar.level[2],"res\\system\\underbar\\LevelNo2.jpg");
	loadimage(&ubar.level[3],"res\\system\\underbar\\LevelNo3.jpg");
	loadimage(&ubar.level[4],"res\\system\\underbar\\LevelNo4.jpg");
	loadimage(&ubar.level[5],"res\\system\\underbar\\LevelNo5.jpg");
	loadimage(&ubar.level[6],"res\\system\\underbar\\LevelNo6.jpg");
	loadimage(&ubar.level[7],"res\\system\\underbar\\LevelNo7.jpg");
	loadimage(&ubar.level[8],"res\\system\\underbar\\LevelNo8.jpg");
	loadimage(&ubar.level[9],"res\\system\\underbar\\LevelNo9.jpg");
	
	ubar.barX = 0;
	ubar.barY = 563;
	ubar.proFlag = NO;
	ubar.packFlag = NO;
	ubar.skiFlag = NO;
	ubar.proX = 572;
	ubar.proY =  565;
	ubar.packX =  647;
	ubar.packY = 565;
	ubar.skiX = 723;
	ubar.skiY = 565;
	ubar.levelX =  50;
	ubar.levelY =  576;
	ubar.levelWidth = 11;
	man.level = 1;
	
	//����
	InitBusInfo();
	
	//������
	InitPacket();
	
	//������
	InitSkillTable();
	
	//������
	InitOperationTool();
	
	// �ָ�ͼƬ
	//�����߶�״̬
	SetWorkingImage(&manmove);
	for(i=0; i<2; ++i)
		for(j=0; j<8; ++j)
			getimage(&man.movepic[i][j],j*62,i*69,62,69);	//width 62 height 69
	//���﹥��״̬
	SetWorkingImage(&manattack);
	for(i=0; i<2; ++i)
		for(j=0; j<6; ++j)
			getimage(&man.attackpic[i][j],j*66,i*69,66,69);
	//����վ��״̬
	SetWorkingImage(&manstand);
	for(i=0; i<2; ++i)
		for(j=0; j<2; ++j)
			getimage(&man.standpic[i][j],j*57,i*70,57,70);
	//������Ծ״̬
	SetWorkingImage(&manjump);
	for(i=0; i<2; ++i)
		for(j=0; j<2; ++j)
			getimage(&man.jumppic[i][j],j*49,i*70,49,70);
	//��ʸ
	SetWorkingImage(&bow);
	for(i=0; i<3; ++i)
		for(j=0; j<2; ++j)
			for(k=0; k<2; ++k)
			getimage(&man.basicAttack[i].attackPic[j][k],k*40,j*7,40,7);
		
	//�˺�ͼƬ
	SetWorkingImage(&damage);
	for(i=0; i<2; ++i)
		for(j=0; j<10; ++j)
			getimage(&damegePic[i][j],j*37,i*40,37,40);
}

void InitPacket()
{
	//427 64
	loadimage(&packet.backPic,"res\\system\\packet.jpg");
	packet.x = 427;
	packet.y = 64;
	packet.flag = NO;
	packet.num[0] = 0;
	packet.num[1] = 0;
}

void InitSkillTable()
{
	loadimage(&skillTable.backPic,"res\\system\\skillTable.jpg");
	skillTable.x = 427;
	skillTable.y = 64;
	skillTable.flag = NO;
	skillTable.num[0] = 0;
	skillTable.num[1] = 0;
	skillTable.totalPoint = 3;
//	skillTable.position[0][0] = 482;
//	skillTable.position[0][1] = 135;
//	skillTable.position[1][0] = 482;
//	skillTable.position[1][1] = 194;
}

void InitOperationTool()
{
	loadimage(&operationTool.toolPic[0],"res\\system\\tool.jpg");
	loadimage(&operationTool.toolPic[1],"res\\system\\ytool.jpg");
	loadimage(&operationTool.selectPic[0],"res\\system\\selectPic.jpg");
	loadimage(&operationTool.selectPic[1],"res\\system\\yselect.jpg");
	loadimage(&operationTool.mark,"res\\system\\toolpic.jpg");
	operationTool.x = 249;
	operationTool.y = 105;
	operationTool.mx = 772;
	operationTool.my = 0;	//26
	operationTool.firstStartX = 356;
	operationTool.firstEndX = 520;
	operationTool.firstStartY = 260;
	operationTool.firstEndY = 300;
	operationTool.secondStartX = 356;
	operationTool.secondEndX = 520;
	operationTool.secondStartY = 301;
	operationTool.secondEndY = 333;
	operationTool.selectPoint[0][0] = 355;
	operationTool.selectPoint[0][1] = 276;
	operationTool.selectPoint[1][0] = 355;
	operationTool.selectPoint[1][1] = 307;
	operationTool.flag = NO;
}

void InitBusInfo()
{
	int i;
	loadimage(&bus.selectPic[0],"res\\system\\selectPic.jpg");
	loadimage(&bus.selectPic[1],"res\\system\\yselect.jpg");
	loadimage(&bus.pagePic[0],"res\\system\\maplist.jpg");
	loadimage(&bus.pagePic[1],"res\\system\\ymaplist.jpg");
	loadimage(&bus.busPic[0],"res\\system\\bus.jpg");
	loadimage(&bus.busPic[1],"res\\system\\ybus.jpg");

	loadimage(&bus.quan[0][4],"res\\system\\M4.jpg");
	loadimage(&bus.quan[1][4],"res\\system\\YM4.jpg");
	bus.x = 183;
	bus.y = 362;
	bus.pX = 146;
	bus.pY = 199;
	bus.quanX = 175;
	bus.quanY = 360;
	bus.firstStartX = 180;
	bus.firstEndX = 360;
	bus.firstStartY = 234;
	bus.firstEndY = 257;
	bus.secondStartX = 180;
	bus.secondEndX = 360;
	bus.secondStartY = 258;
	bus.secondEndY = 281;
	bus.thirdStartX = 180;
	bus.thirdEndX = 360;
	bus.thirdStartY = 282;
	bus.thirdEndY = 305;
	bus.fourthStartX = 180;
	bus.fourthEndX = 360;
	bus.fourthStartY = 306;
	bus.fourthEndY = 330;
	bus.index = 0;
	//9*12
	for(i=0; i<4; ++i)
	{
		bus.selectPoint[i][0] = 213;
		bus.selectPoint[i][1] = 241 + i*25;
	}
	bus.quanTag = YES;
	bus.chancelTag = NO;
	bus.selectTag = NO;
	bus.goMapTag = NO;
}

void InitSkillInfo()
{
  	//x,y��ӡ��ʱ��Ҫ�������ж�
	int i;
	
	for(i=0; i<3; ++i)
	{
		man.basicAttack[i].delX = 300; 			//���޾���
		man.basicAttack[i].width = 40;
		man.basicAttack[i].high = 7;
		man.basicAttack[i].attackPower = 20;
		man.basicAttack[i].speed = 20;
		man.basicAttack[i].alive = NO;			//����ʱ����
	}
}

void InitMonster()
{
	IMAGE FMushroom;
	int i,j,k;
	loadimage(&FMushroom,"res\\monster\\hua65.jpg");
	SetWorkingImage(&FMushroom);
	for(k=0; k<6; ++k)
		for(i=0; i<2; ++i)
			for(j=0; j<8; ++j)
				getimage(&flowerMushroom[k].movepic[i][j],j*65,i*68,65,68);
	
	for(i=0; i<6; ++i)
	{
		flowerMushroom[i].width = 65;
		flowerMushroom[i].high = 68;
		flowerMushroom[i].basicAttackPower = 5;
		flowerMushroom[i].speed = 3;
		flowerMushroom[i].alive = YES;
		flowerMushroom[i].blood = 60;
		flowerMushroom[i].judgeTerm = 1;
		flowerMushroom[i].img_num = 3;
		flowerMushroom[i].img_index = 0;
		flowerMushroom[i].tag = FlowerMushroom;
		flowerMushroom[i].arrow = left;
		flowerMushroom[i].flag = YES;
	}
	//��һ��
	flowerMushroom[0].x = 400;
	flowerMushroom[0].y = 90;
	flowerMushroom[0].rightEdge = 750;
	flowerMushroom[0].leftEdge = 300;
	flowerMushroom[1].x = 600;
	flowerMushroom[1].y = 90;
	flowerMushroom[1].rightEdge = 750;
	flowerMushroom[1].leftEdge = 300;
	//�ڶ���
	flowerMushroom[2].x = 700;
	flowerMushroom[2].y = 260;
	flowerMushroom[2].rightEdge = 890;
	flowerMushroom[2].leftEdge = 230;
	//������	
	flowerMushroom[3].x = 700;
	flowerMushroom[3].y = 440;
	flowerMushroom[3].rightEdge = 1110;
	flowerMushroom[3].leftEdge = 0;
	flowerMushroom[4].x = 700;
	flowerMushroom[4].y = 440;
	flowerMushroom[4].rightEdge = 1110;
	flowerMushroom[4].leftEdge = 0;
	flowerMushroom[5].x = 700;
	flowerMushroom[5].y = 440;
	flowerMushroom[5].rightEdge = 1110;
	flowerMushroom[5].leftEdge = 0;
}


void LoadMusic()
{
	//Tab.mp3
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\WzLogo.mp3\" alias Begin", NULL, 0, NULL);
	//����
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\Tab.mp3\" alias Tab", NULL, 0, NULL);
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\BtMouseClick.mp3\" alias Mousehit", NULL, 0, NULL); // �����
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\Jump.mp3\" alias Jump", NULL, 0, NULL);				// ��Ծ
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\LevelUp.mp3\" alias LevelUp", NULL, 0, NULL);		// ����
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\PickUpItem.mp3\" alias Pick", NULL, 0, NULL);		// ����
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\QuestAlert.mp3\" alias Tip", NULL, 0, NULL);		// ��ʾ
	//����
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\Bow.mp3\" alias Bow", NULL, 0, NULL);			//��ͨ����
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\Skill01.mp3\" alias SkillA", NULL, 0, NULL);	//����A �ᴩ��
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\Skill02.mp3\" alias SkillS", NULL, 0, NULL);	//����S ��Ҷɨ��
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\monsterdie.mp3\" alias MonsterDie", NULL, 0, NULL);	//����S ��Ҷɨ��
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\monsterattacked.mp3\" alias MonAttacked", NULL, 0, NULL);	//����S ��Ҷɨ��

	//��ͼ
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\RestNPeace.mp3\" alias MapFirst", NULL, 0, NULL);//�ɿ�
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\WhenTheMorningComes.mp3\" alias MapleNPC", NULL, 0, NULL);//�ɿ�
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\MoonlightShadow.mp3\" alias MapleMagical", NULL, 0, NULL);//ħ�����ֹ���ش�
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\GoShanghai.mp3\" alias ShangHai", NULL, 0, NULL);//��������
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\ShanghaiField.mp3\" alias WuGong", NULL, 0, NULL);//���
	mciSendString("open \"C:\\Users\\Administrator\\Desktop\\maple\\�汾01\\res\\music\\SnowyVillage.mp3\" alias SnowCity", NULL, 0, NULL);//����ѩ��
}