void InitSecondMap()
{
	int i;
	man.x = 260;
	man.y = 392 - man.high;	//��Ҫ��ȥ����߶�
	
	x = 0;

	maple[2].width = 1073;
	maple[2].hight = 600;
	maple[2].sub_length = 273;
	
	secondPoint[0].pX = 485;
	secondPoint[0].pY = 500 - man.high;
	secondPoint[0].nextPoint[0][0] = 550;//��һ������
	secondPoint[0].nextPoint[0][1] = 392 - man.high;

	secondPoint[1].pX = 625;
	secondPoint[1].pY = 372 - man.high;
	secondPoint[1].nextPoint[0][0] = 550;
	secondPoint[1].nextPoint[0][1] = 520 - man.high;
	loadimage(&pointIco[0],"res\\system\\yj.jpg");
	loadimage(&pointIco[1],"res\\system\\j.jpg");
	
	//	63
/*	maple[2].t[0][0] = NO;
	maple[2].t[0][1] = 63/4 + 63%4;
	for(i=2; i<5; ++i)
		maple[2].t[0][i] = 63/4;
	
	maple[2].t[1][0] = NO;
	maple[2].index = 1;
	*/
	//������س�ʼ��
	SlideTag = 0;
	snowAdd = 0;
	
	
	//����ͼƬ
	loadimage(&maple[2].background,"res\\map\\second_map.jpg");
	//loadimage(&Duck);
	
	//msMove[8]�Ѿ���ʼ��
}