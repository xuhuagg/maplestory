

//�����������
//1.ԭ����
//2.��������

void GetCmd(MapleInfo maple)
{
	MapTransJudge();		//���ڼ���ͼ�е�ת�Ƶ�
	ManCmdJudge(maple);		//����ת���ж�
	MapEdgeJudge();			//��background.cpp��������ﵽ��߽��������ж�
	DispatchMove(maple);
	DispatchJump();
	DispatchAttack();
}

void MapTransJudge()
{
		//���Ƶ�ͼ���л�
	
	if((GetAsyncKeyState(VK_UP) & 0x8000))
	{
		if(showFirstMap == YES)
		{
			if(man.y>360 && man.x-x>=340 && man.x-x<=390)
			{
				man.x = firstPoint[0].nextPoint[firstPoint[0].flag][0]+x;
				man.y = firstPoint[0].nextPoint[firstPoint[0].flag][1];
				firstPoint[1].flag = YES;
			}
			else if(man.y<360 && man.y>180 && man.x-x>=595 && man.x-x<=640)
			{
				man.x = firstPoint[1].nextPoint[firstPoint[1].flag][0]+x;
				man.y = firstPoint[1].nextPoint[firstPoint[1].flag][1];
				firstPoint[1].flag = NO;
			}
			else if(man.y<150 && man.x-x>=560 && man.x-x<=605)
			{
				man.x = firstPoint[2].nextPoint[1][0]+x;
				man.y = 258;//firstPoint[2].nextPoint[1][1]
			}
		//	Sleep(10);
		}
		
		if(showSecondMap == YES)
		{
			int width = 0;
			width = man.x - x+man.width;
			if(man.y == 520 - man.high)
			{
				if(width >= 480 && width <= 540)				//һ��
				{
					man.x = secondPoint[0].nextPoint[0][0]+x;
					man.y = secondPoint[0].nextPoint[0][1];
				}				
			}
			if(man.y == 392 - man.high)
			{
				if(width >= 625 && width <= 685)
				{
					man.x = secondPoint[1].nextPoint[0][0]+x;
					man.y = secondPoint[1].nextPoint[0][1];
				}
			}
		}
	}
}

void ManCmdJudge(MapleInfo maple)
{
	if((GetAsyncKeyState(VK_LEFT) & 0x8000) && attackTag ==NO) OnLeft(maple);
	else if((GetAsyncKeyState(VK_RIGHT) & 0x8000 ) && attackTag == NO) OnRight(maple);
	else{
		if(attackTag == NO && jumpTag == NO)
		{
			if(man.arrow == left)
			{
				putimage(man.x,man.y,&man.standpic[1][0],NOTSRCERASE);//57,70
				putimage(man.x,man.y,&man.standpic[0][0],SRCINVERT);//57,70
			}
			else
			{
				putimage(man.x,man.y,&man.standpic[1][1],NOTSRCERASE);//57,70
				putimage(man.x,man.y,&man.standpic[0][1],SRCINVERT);//57,70
			}
		}		
	}
	if(GetAsyncKeyState(VK_SHIFT) & 0x8000&& attackTag == NO) OnAttack();
	if((GetAsyncKeyState(VK_CONTROL) & 0x8000) && jumpTag == NO) OnJump();
}

void OnLeft(MapleInfo maple)
{
	man.arrow = left;
	moveTag = YES;
}

void OnRight(MapleInfo maple)
{
	man.arrow = right;
    moveTag = YES;

}

void DispatchMove(MapleInfo maple)
{
	//��ͼ��:�Ի����Ĵ���
	if(showSecondMap == YES)
	{
		if(moveTag == YES)
		{
			if(man.arrow == left)
				SlideTag = -1;
			else
				SlideTag = 1;
			if(snowAdd < -12)		//���⻬���ٶȹ��� 
				snowAdd = -12;
			if(snowAdd > 12)
				snowAdd = 12;
			snowAdd += SlideTag;
		}
		else
		{
			if(snowAdd !=0)
			{
				x -= snowAdd/3;		//ʹ��ͼ�����ƶ�
				if(x >= 0)
					x = 0;
				if(x <= -maple.sub_length)
					x = -maple.sub_length;	//�����ͼ��λ
			}
			if(snowAdd > 0)
				snowAdd -= 1;
			if(snowAdd < 0)
				snowAdd += 1;
		}
		man.x += snowAdd;
		if(man.x <= 0)
			man.x = 0;
		if(man.x >= 740)
			man.x = 740;
	}
	if(moveTag == YES)
	{
		if(man.arrow == left)
		{
			if(x >= 0)
			{
				man.x -= (man.speed);
			}
			else
				HandleX(man.speed/2);
			if(man.x<=0)
				man.x=0;
		}
		if(man.arrow == right)
		{
			if(x <= -maple.sub_length)
			{
				man.x += (man.speed);
			}
			else
				HandleX(-man.speed/2);
			if(man.x - x + man.width >= maple.width)
				man.x = maple.width + x - man.width;
		}
		PrintMoveGif();
		moveTag = NO;
		
	}
	
}

void OnJump()
{
	mciSendString("play Jump from 0", NULL, 0, NULL);
	jumpTag = YES;
}

void DispatchJump()
{
	if(jumpTag == YES)
	{
		man.y -= _jump[(jump)++];
		PrintJumpGif();
	}
	if(jump == 10)
	{
		jump = 0;
		jumpTag = NO;
	}
}

void OnAttack()
{
	mciSendString("play Bow from 0", NULL, 0, NULL);
	attackTag = YES;
	BowRefresh();
}

void DispatchAttack()
{
	if(attackTag == YES)
	{
		int i = (attack++)%3;
		if(man.arrow == left)
		{
			putimage(man.x-19,man.y,&man.attackpic[1][i],NOTSRCERASE);
			putimage(man.x-19,man.y,&man.attackpic[0][i],SRCINVERT);
		}
		else if(man.arrow == right)
		{
			putimage(man.x+10,man.y,&man.attackpic[1][i+3],NOTSRCERASE);
			putimage(man.x+10,man.y,&man.attackpic[0][i+3],SRCINVERT);
		}
		if(attack == 4)
		{
			attack = 0;
			attackTag = NO;
		}
	}
	BowMove();
}

void HandleX(int delt)
{
	man.x -= delt;		//������ǲ�ͬ����ԭ��
	x += delt;
}

void PrintAttackGif()
{
	int i;
	i=(man.img_index++)%3;
	if(man.arrow == left)
	{
		putimage(man.x,man.y,&man.attackpic[1][i],NOTSRCERASE);
		putimage(man.x,man.y,&man.attackpic[0][i],SRCINVERT);
	}
	else
	{
		i = i+3;
		putimage(man.x,man.y,&man.attackpic[1][i],NOTSRCERASE);
		putimage(man.x,man.y,&man.attackpic[0][i],SRCINVERT);
	}
	Sleep(20);
}

void PrintJumpGif()
{
	if(man.arrow == left)
	{
		
		putimage(man.x,man.y,&man.jumppic[1][0],NOTSRCERASE);
		putimage(man.x,man.y,&man.jumppic[0][0],SRCINVERT);
	}
	else
	{
		putimage(man.x,man.y,&man.jumppic[1][1],NOTSRCERASE);
		putimage(man.x,man.y,&man.jumppic[0][1],SRCINVERT);
	}
//	FlushBatchDraw();
//	Sleep(5);
}

void PrintMoveGif()
{
	int i;
	int flag = YES;
	if(showFirstMap == YES && (maple[1].t[0][0] == YES || maple[1].t[1][0] == YES))//�ж��Ƿ��ڿ���
		flag = NO;
	if(showSecondMap == YES && (maple[2].t[0][0] == YES))
		flag = NO;
	if(jumpTag != YES && flag){								//�����ƶ�
		if(man.arrow == left)
		{
			i=(man.img_index++)%4;
			putimage(man.x,man.y,&man.movepic[1][i],NOTSRCERASE);
			putimage(man.x,man.y,&man.movepic[0][i],SRCINVERT);
		}
		else
		{
			i=(man.img_index++)%4+4;
			putimage(man.x,man.y,&man.movepic[1][i],NOTSRCERASE);
			putimage(man.x,man.y,&man.movepic[0][i],SRCINVERT);
		}
	}
	if(flag == NO)												//�ڿ��е����
	{
		if(man.arrow == left)
		{
			
			putimage(man.x,man.y,&man.jumppic[1][0],NOTSRCERASE);
			putimage(man.x,man.y,&man.jumppic[0][0],SRCINVERT);
		}
		else
		{
			putimage(man.x,man.y,&man.jumppic[1][1],NOTSRCERASE);
			putimage(man.x,man.y,&man.jumppic[0][1],SRCINVERT);
		}		
	}
}
