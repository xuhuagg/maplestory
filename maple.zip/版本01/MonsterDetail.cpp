void MonsterMove()
{
	if(showFirstMap == YES)
	{
		GetMonsterDirection(1);
	}
}

void GetMonsterDirection(int term)
{
	int i,rightX,leftX;
	if(term == 1)
	{
		for(i=0; i<6; ++i)
		{
			if(flowerMushroom[i].alive == NO)
				continue;
			if(flowerMushroom[i].flag == YES)
			{
				flowerMushroom[i].directNum = msMove[rand()%8];
				if(flowerMushroom[i].directNum < 0)
					flowerMushroom[i].arrow = left;
				if(flowerMushroom[i].directNum > 0)
					flowerMushroom[i].arrow = right;
				flowerMushroom[i].flag = NO;
				flowerMushroom[i].directNum = abs(flowerMushroom[i].directNum);
			}
			else
			{
				if(flowerMushroom[i].judgeTerm == flowerMushroom[i].directNum)				//如果指定方向位移走完则重置
				{
						flowerMushroom[i].flag = YES;
						flowerMushroom[i].judgeTerm = 1;
				}
				if(flowerMushroom[i].arrow == left)					//向左移动
				{
					leftX = flowerMushroom[i].x - flowerMushroom[i].speed;
					if(leftX < flowerMushroom[i].leftEdge)
						flowerMushroom[i].x = flowerMushroom[i].leftEdge;
					else
						flowerMushroom[i].x -= flowerMushroom[i].speed;
					putimage(flowerMushroom[i].x+x,flowerMushroom[i].y,&flowerMushroom[i].movepic[1][(flowerMushroom[i].img_index/10)%2+1],NOTSRCERASE);
					//减慢刷图速度
					putimage(flowerMushroom[i].x+x,flowerMushroom[i].y,&flowerMushroom[i].movepic[0][(flowerMushroom[i].img_index/10)%2+1],SRCINVERT);
					flowerMushroom[i].img_index++;
				}
				
				if(flowerMushroom[i].arrow == right)					//向右移动
				{
					rightX = flowerMushroom[i].x + flowerMushroom[i].speed;
					if(rightX > flowerMushroom[i].rightEdge)
						flowerMushroom[i].x = flowerMushroom[i].rightEdge;
					else
						flowerMushroom[i].x += flowerMushroom[i].speed;
					putimage(flowerMushroom[i].x+x,flowerMushroom[i].y,&flowerMushroom[i].movepic[1][(flowerMushroom[i].img_index/10)%2+3],NOTSRCERASE);
					putimage(flowerMushroom[i].x+x,flowerMushroom[i].y,&flowerMushroom[i].movepic[0][(flowerMushroom[i].img_index/10)%2+3],SRCINVERT);
					flowerMushroom[i].img_index++;
				}
			
				flowerMushroom[i].judgeTerm++;
			}
		}
		
	}
}

