
void ReadyGo()
{
	x = 0;
	BeginBatchDraw();
	do
	{
		putimage(x,0,&maple[0].background);
		ShowUnderBar();
		ShowExpColumn();
		ShowBus();
//		ShowTransfer(1);
		GetCmd(maple[0]);
		ShowPacket();
		ShowSkillTable();
		ShowOperationTool();
		while(MouseHit())
		{
			MS = GetMouseMsg();
			Mouse(MS);
			SelectColumn(MS);
		}
		putimage(MS.x,MS.y,&mouse[1],NOTSRCERASE);
		putimage(MS.x,MS.y,&mouse[0],SRCINVERT);
		FlushBatchDraw();
		Sleep(20);

	}while(showReadyMap!=NO);
	mciSendString("stop MapleNPC", NULL, 0, NULL);
	Sleep(500);
	EndBatchDraw();
	cleardevice();
}

void GameRule()
{
	initgraph(SCREENWIDTH,SCREENHEIGHT);
	IMAGE tip01,tip02;
	loadimage(&tip01,"res\\system\\tip.jpg");
	loadimage(&tip02,"res\\system\\tip01.jpg");
	mciSendString("play Tip from 0", NULL, 0, NULL);
	mciSendString("play MapleNPC from 0", NULL, 0, NULL);
	BeginBatchDraw();
	do
	{
		putimage(0,0,&maple[0].background);
//		PrintStandGif();
//		ShowTransfer(1);
		putimage(320,100,&tip01);
		putimage(man.x,385,&man.standpic[1][0],NOTSRCERASE);//57,70
		putimage(man.x,385,&man.standpic[0][0],SRCINVERT);//57,70
		while(MouseHit())
		{
			MS = GetMouseMsg();
			Mouse(MS);
			if((MS.x>=500 && MS.x<=560)&&(MS.y>=100 && MS.y<=135))
			{
				mciSendString("play Tab from 0", NULL, 0, NULL);
//				Sleep(10);
				if(MS.mkLButton)
				{
					showTip=NO;
					showReadyMap = YES;
					putimage(320,100,&tip02);
					Sleep(10);
				}
			}
		}
		putimage(MS.x,MS.y,&mouse[1],NOTSRCERASE);
		putimage(MS.x,MS.y,&mouse[0],SRCINVERT);
		
		FlushBatchDraw();
	}while(showTip != NO);			
	
//	if( iOpenMusic)					
//		mciSendString("play Key from 0", NULL, 0, NULL);

	Sleep(100);
	EndBatchDraw();
	//mciSendString("stop MapleNPC from 0", NULL, 0, NULL);
//	closegraph();
//	cleardevice();
}