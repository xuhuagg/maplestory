void SecondMap()
{
	InitSecondMap();
	mciSendString("play SnowCity from 0", NULL, 0, NULL);
	BeginBatchDraw();
	do
	{
		putimage(x,0,&maple[2].background);
		ShowUnderBar();
		ShowExpColumn();
		ShowTransPoint();
		//MonsterMove();
		GetCmd(maple[2]);
		ShowPacket();
		ShowSkillTable();
		ShowOperationTool();
		while(MouseHit())
		{
			MS = GetMouseMsg();
			Mouse(MS);
			SelectColumn(MS);
		}
		putimage(MS.x,MS.y,&mouse[1],NOTSRCERASE);
		putimage(MS.x,MS.y,&mouse[0],SRCINVERT);
		FlushBatchDraw();
		Sleep(20);		
		
	}while(showSecondMap != NO);	
}