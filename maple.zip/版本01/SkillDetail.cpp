void BowRefresh()
{
	int deltx = 0;
	if(man.arrow == left)
		deltx = -5 - x;
	else
		deltx = man.width+5 - x;
	if(man.basicAttack[0].alive == NO)
	{
		man.basicAttack[0].originX = man.x+deltx;
		man.basicAttack[0].arrow = man.arrow;
		man.basicAttack[0].x = man.x+deltx;
		man.basicAttack[0].y = man.y+40;
		man.basicAttack[0].alive = YES;
	}
	else if(man.basicAttack[0].alive == YES && man.basicAttack[1].alive == NO)
	{
		man.basicAttack[1].originX = man.x+deltx;
		man.basicAttack[1].arrow = man.arrow;
		man.basicAttack[1].x = man.x+deltx;
		man.basicAttack[1].y = man.y+40;
		man.basicAttack[1].alive = YES;
	}
	else if(man.basicAttack[1].alive == YES && man.basicAttack[2].alive == NO)
	{
		man.basicAttack[2].originX = man.x+deltx;
		man.basicAttack[2].arrow = man.arrow;
		man.basicAttack[2].x = man.x+deltx;
		man.basicAttack[2].y = man.y+40;
		man.basicAttack[2].alive = YES;		
	}
	
}

void BowMove()
{
	int i;
	for(i=0; i<3; ++i)
	{
		if(man.basicAttack[i].alive == YES)
		{
			switch(man.basicAttack[i].arrow)
			{
				case right:
					man.basicAttack[i].x += man.basicAttack[i].speed;
					putimage(man.basicAttack[i].x + x,man.basicAttack[i].y,&man.basicAttack[i].attackPic[1][1],NOTSRCERASE);
					putimage(man.basicAttack[i].x + x,man.basicAttack[i].y,&man.basicAttack[i].attackPic[0][1],SRCINVERT);
					break;
				case left:
					man.basicAttack[i].x -= man.basicAttack[i].speed;
					putimage(man.basicAttack[i].x + x,man.basicAttack[i].y,&man.basicAttack[i].attackPic[1][0],NOTSRCERASE);
					putimage(man.basicAttack[i].x + x,man.basicAttack[i].y,&man.basicAttack[i].attackPic[0][0],SRCINVERT);
					break;
				default:
					break;
			}
			if(showFirstMap == YES)
				MeetMonsterJudge(FlowerMushroom,i);
		}
		if(man.basicAttack[i].x < 0 || abs(man.basicAttack[i].x - man.basicAttack[i].originX) > man.basicAttack[i].delX)			//射出距离超过delX失效
			man.basicAttack[i].alive = NO;																							//超出地图边界失效
		if((showReadyMap == YES && man.basicAttack[i].x > maple[0].width)||(showFirstMap == YES && man.basicAttack[i].x > maple[1].width))
			man.basicAttack[i].alive = NO;
		/*if((showSecondMap == YES && man.basicAttack[i].x > maple[2].width)||(showThirdMap == YES && man.basicAttack[i].x > maple[3].width)
			|| (showFourthMap == YES && man.basicAttack[i].x > maple[4].width))
			man.basicAttack[i].alive = NO;
		*/
	}
}

void MeetMonsterJudge(int tag,int term)
{
	int i,j,flag,power;
	if(tag == FlowerMushroom)
	{
		for(i=0; i<6; ++i)
		{
			if(flowerMushroom[i].alive == YES)
			{
				flag = MeetSkillJudge(man.basicAttack[term],flowerMushroom[i]);
				if(flag == YES)
				{
					power = man.basicAttack[term].attackPower - 10 + rand()%11;
					ShowDamagePic(power,i,FlowerMushroom);
					mciSendString("play MonAttacked from 0", NULL, 0, NULL);
					flowerMushroom[i].blood -= man.basicAttack[term].attackPower;
					man.basicAttack[term].alive = NO;
					if(flowerMushroom[i].blood <= 0)
					{
						flowerMushroom[i].alive = NO;
						mciSendString("play MonsterDie from 0", NULL, 0, NULL);
					}
					break;
				}
			}
		}
	}
}

int MeetSkillJudge(Skill src,Monster goal)
{
    if(src.x >= goal.x && src.x <= goal.x + goal.width
		&& src.y >= goal.y && src.y <= goal.y + goal.high) {
		return YES;
	}
	if(src.x+src.width >= goal.x && src.x+src.width <= goal.x + goal.width
		&& src.y >= goal.y && src.y <= goal.y + goal.high) {
		return YES;
	}
	if(src.x >= goal.x && src.x <= goal.x + goal.width
		&& src.y+src.high >= goal.y && src.y+src.high <= goal.y + goal.high) {
		return YES;
	}
	if(src.x+src.width >= goal.x && src.x+src.width <= goal.x + goal.width
		&& src.y+src.high >= goal.y && src.y+src.high <= goal.y + goal.high) {
		return YES;
	}
	return NO;
}
