
void Welcome()
{
	initgraph(SCREENWIDTH,SCREENHEIGHT);
	IMAGE begin;
	loadimage(&begin,"res\\map\\begin.jpg");
	int j;
	int r,g,b;
	r=g=b=192;
	setfont(150,0,"��Բ");
	setbkcolor(WHITE);
	mciSendString("play Begin from 0", NULL, 0, NULL);
	BeginBatchDraw();
	cleardevice();
	putimage(0,0,&begin);
	for(j=0;j<190;j++)
	{
		setcolor( RGB( r-- , g--, b--));
		putimage(0,0,&begin);
		outtextxy(160,200,"��֮��");
		FlushBatchDraw();
		Sleep(10);
	}
	for(j=0;j<190;j++)
	{
		setcolor( RGB( r++ , g++, b++));
		putimage(0,0,&begin);
		outtextxy(160,200,"��֮��");
		FlushBatchDraw();
		Sleep(20);
	}

	EndBatchDraw();
	cleardevice();
}
