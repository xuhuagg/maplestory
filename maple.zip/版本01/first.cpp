#include "Head.h"
#include "Welcome.cpp"
#include "InitBeginPlace.cpp"
#include "ReadyGo.cpp"
#include "ManDetial.cpp"
#include "InitFirstMap.cpp"
#include "FirstMap.cpp"
#include "MonsterDetail.cpp"
#include "SkillDetail.cpp"
#include "Background.cpp"
#include "SecondMap.cpp"
#include "InitSecondMap.cpp"


int main(void)
{
	InitBeginPlace();
	LoadMusic();
	Welcome();
	GameRule();
	do
	{
		ReadyGo();
		switch(mapTag)
		{
			case First:
				FirstMap();
				mciSendString("stop MapFirst", NULL, 0, NULL);
				break;
			case Second:
				SecondMap();
				mciSendString("stop SnowCity", NULL, 0, NULL);
				break;
			default:
				break;	
		}
		cleardevice();
		mciSendString("play MapleNPC from 0", NULL, 0, NULL);
		man.x = 400;
		man.y = 385;
	}while(showReadyMap != NO);
	
	return 0;
}
